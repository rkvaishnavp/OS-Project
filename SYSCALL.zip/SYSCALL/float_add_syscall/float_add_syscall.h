#ifndef _ADD_SYSCALL_H_
#define _ADD_SYSCALL_H_
#include <linux/linkage.h>
asmlinkage long sys_float_add_call(int, int);
#endif
