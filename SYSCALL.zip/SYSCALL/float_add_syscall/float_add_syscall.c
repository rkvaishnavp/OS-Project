#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/syscalls.h>
#include "float_add_syscall.h"

SYSCALL_DEFINE2(float_add_syscall, int, float_number1,int,float_number2)
{

	int overflow_error = 0x7F800000;

	int exponent1 = float_number1&(0b01111111100000000000000000000000);
	int mantissa1 = float_number1&(0b00000000011111111111111111111111);
	
	int exponent2 = float_number2&(0b01111111100000000000000000000000);
	int mantissa2 = float_number2&(0b00000000011111111111111111111111);
	
	int resultant_mantissa;
	int resultant_exponent;
	
	int resultant_float;
	
	if(exponent1 == exponent2)
	{
		resultant_mantissa=((mantissa1+mantissa2)>>1)&(0b00000000011111111111111111111111);
		resultant_exponent=exponent1+0b00000000100000000000000000000000;
		resultant_float = resultant_exponent|resultant_mantissa;
	}
	else{
	int difference_exponent;
		if(exponent1 > exponent2){
			difference_exponent = (exponent1 - exponent2)>>23;
			mantissa2 = (mantissa2>>1) | 0b10000000000000000000000;
			mantissa2 = mantissa2>>(difference_exponent-1);
			resultant_exponent = exponent1;
			resultant_mantissa = mantissa1 + mantissa2;
			if(resultant_mantissa & 0b00000000100000000000000000000000){
				resultant_mantissa = resultant_mantissa>>1;
				resultant_mantissa = resultant_mantissa & 0b00000000101111111111111111111111;
				resultant_exponent = resultant_exponent + 0b00000000100000000000000000000000;
			}
			if(resultant_exponent & 0b10000000000000000000000000000000){
				return -1;
			}
			resultant_float = resultant_exponent|resultant_mantissa;
		}
		else{
			difference_exponent = (exponent2 - exponent1)>>23;
			mantissa1 = (mantissa1>>1) | 0b10000000000000000000000;
			mantissa1 = mantissa1>>(difference_exponent-1);
			resultant_exponent = exponent2;
			resultant_mantissa = mantissa1 + mantissa2;
			if(resultant_mantissa & 0b00000000100000000000000000000000){
				resultant_mantissa = resultant_mantissa>>1;
				resultant_mantissa = resultant_mantissa & 0b00000000101111111111111111111111;
				resultant_exponent = resultant_exponent + 0b00000000100000000000000000000000;
			}
			if(resultant_exponent & 0b10000000000000000000000000000000){
				return overflow_error;
			}
			resultant_float = resultant_exponent|resultant_mantissa;
		}
	}

	return resultant_float; 

}
