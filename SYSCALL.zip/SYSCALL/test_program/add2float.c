#include <stdio.h>
#include <unistd.h>

#define MY_SYSCALL 449

float addFloat(float num1,float num2)
{

	int Intnum1,Intnum2,Intresult;
	Intnum1= *(int*)&num1;
	Intnum2= *(int*)&num2;
	float result=-1.0;
	int infinity = 0b01111111100000000000000000000000;
	if(Intnum1==0||Intnum2==0)
		printf("One of the inputs was zero\n");
	else if(Intnum1<0||Intnum2<0)
		printf("Negative Inputs are not accepted\n");
	else if(Intnum1==infinity||Intnum2==infinity)
		printf("Overflow Error. Input number very Large.\n");
	else
	{
		Intresult = syscall(MY_SYSCALL,Intnum1,Intnum2);
		result = *(float*)&Intresult;
	}
	if(Intresult>infinity)
	{	printf("Overflow Error\n");
		result=-1.0;
	}
	return result;
}
int main(int argc,char *argv[])
{
	float num1, num2, result;
	printf("Enter Number 1 and Number 2\n");
	scanf("%f %f", &num1, &num2);
	printf("Adding Two Float Numbers %f and %f  in System Call\n",num1,num2);
	
	result=addFloat(num1,num2);
	if(result!=-1)
	{
		printf("The Result is %f\n",result);
	}

	
	return 0;
}
